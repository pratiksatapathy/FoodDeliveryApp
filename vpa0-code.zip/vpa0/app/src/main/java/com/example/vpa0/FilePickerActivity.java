package com.example.vpa0;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import java.io.File;
import java.io.IOException;

public class FilePickerActivity extends AppCompatActivity {

    private static final int REQUEST_FILE_PICKER = 1;
    private File selectedFile;
    ProgressBar progressBar;
    ImageView imaveview2;
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_qr_code_scanner);
        TextView textViewa = findViewById(R.id.textViewa);
        TextView textViewb = findViewById(R.id.textViewb);
        progressBar = findViewById(R.id.progressBar);
        progressBar.setVisibility(View.INVISIBLE);
        imaveview2 = findViewById(R.id.imageView2);
        textViewa.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                progressBar.setVisibility(View.VISIBLE);
                updateProgressMessage("Performing token exchange from VPA and authenticating with issuer");

                // Simulate an asynchronous process
                // Replace this with actual API calls and logic
                new android.os.Handler().postDelayed(
                        new Runnable() {
                            public void run() {
                                imaveview2.setVisibility(View.VISIBLE);
                                updateProgressMessage("Payment completed!");
                                new android.os.Handler().postDelayed(
                                        new Runnable() {
                                            public void run() {
                                                imaveview2.setVisibility(View.VISIBLE);
                                                progressBar.setVisibility(View.GONE);


                                                Intent intent = new Intent(FilePickerActivity.this, CardListActivity.class);

// If you want to pass data, add extras to the Intent
//                                                intent.putExtra("cardnum", cardnum.getText()); // Replace "key" with your data key and "value" with the actual data

                                                startActivity(intent);
                                                // Implement logic to save card data and navigate to next activity
                                            }
                                        }, 3000);
                            }
                        }, 1000);
            }
        });

    }
    private void updateProgressMessage(String message) {
        // Update the progress message TextView here
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }


}

