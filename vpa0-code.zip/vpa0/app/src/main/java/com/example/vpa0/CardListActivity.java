package com.example.vpa0;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ProgressBar;
import android.widget.TextView;

import java.io.File;

public class CardListActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private ProgressBar progressBar;
    private ImageButton addButton;
    private ImageButton impageButton3;

    private static final int REQUEST_FILE_PICKER = 1;
    private File selectedFile;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_card_list);

        progressBar = findViewById(R.id.progressBar);

        // Set up RecyclerView and adapter
        // Replace this with your actual RecyclerView setup logic

       progressBar.setVisibility(View.VISIBLE);
        new android.os.Handler().postDelayed(
                new Runnable() {
                    public void run() {
                        progressBar.setVisibility(View.GONE);
                    }
                },2000);


        Intent intent = getIntent();

// For different data types
        String cn = intent.getExtras()==null?null:intent.getExtras().get("cardnum").toString();
        if(cn!=null){
        View rootView = findViewById(R.id.card3); // Replace with the actual ID of your root layout
        rootView.setVisibility(View.VISIBLE);
        TextView textView  = findViewById(R.id.textViewc);
        textView.setText("XXXX XXXX "+cn.substring(cn.length()-4)+"|newpratik@visaVPA");
        }


//        updateProgressMessage("Loading cards...");
        addButton = findViewById(R.id.imageButton4);
        addButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//                progressBar.setVisibility(View.VISIBLE);
                //              updateProgressMessage("Requesting for VPA...");
                Intent intent = new Intent(CardListActivity.this, AddCreditCardActivity.class);
                startActivity(intent);
                // Simulate an asynchronous process
                // Replace this with actual API calls and logic


            }
        });

        impageButton3 = findViewById(R.id.imageButton3);
        impageButton3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//                progressBar.setVisibility(View.VISIBLE);
                //              updateProgressMessage("Requesting for VPA...");
                openFilePicker();

                // Simulate an asynchronous process
                // Replace this with actual API calls and logic


            }
        });
    }

    private void openFilePicker() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("*/*"); // Allow all file types
        startActivityForResult(intent, REQUEST_FILE_PICKER);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_FILE_PICKER && resultCode == RESULT_OK && data != null) {
            Uri uri = data.getData();
            Intent intent = new Intent(CardListActivity.this, FilePickerActivity.class);
            startActivity(intent);
        }
    }

    private void updateProgressMessage(String message) {
        // Update the progress message TextView here
    }
}
