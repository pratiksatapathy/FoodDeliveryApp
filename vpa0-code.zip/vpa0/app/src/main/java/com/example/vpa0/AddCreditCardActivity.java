package com.example.vpa0;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ProgressBar;
import android.widget.Toast;

import androidx.annotation.Nullable;

public class AddCreditCardActivity extends Activity {

    ImageButton imageButton;
    ProgressBar progressBar;
    EditText cardnum;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_credit_card);
        imageButton = findViewById(R.id.imageButton);
        progressBar = findViewById(R.id.progressBar);
        progressBar.setVisibility(View.GONE);
        cardnum = findViewById(R.id.editTextTextc2);
        imageButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                progressBar.setVisibility(View.VISIBLE);
                updateProgressMessage("Requesting for VPA...");

                // Simulate an asynchronous process
                // Replace this with actual API calls and logic
                new android.os.Handler().postDelayed(
                        new Runnable() {
                            public void run() {
                                updateProgressMessage("Getting token...");

                                new android.os.Handler().postDelayed(
                                        new Runnable() {
                                            public void run() {
                                                progressBar.setVisibility(View.GONE);
                                                updateProgressMessage("Card added successfully!");
                                                Intent intent = new Intent(AddCreditCardActivity.this, CardListActivity.class);

// If you want to pass data, add extras to the Intent
                                                intent.putExtra("cardnum", cardnum.getText()); // Replace "key" with your data key and "value" with the actual data

                                                startActivity(intent);
                                                // Implement logic to save card data and navigate to next activity
                                            }
                                        }, 2000);
                            }
                        }, 2000);
            }
        });
    }
    private void updateProgressMessage(String message) {
        // Update the progress message TextView here
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }
}
